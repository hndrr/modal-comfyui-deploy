// ComfyUI Frontend 1.53.6 compatibility boundary. Only this adapter touches the
// execution store: external /prompt callers don't go through app.queuePrompt,
// so native workflow progress needs the same storeJob registration explicitly.
export function executionGraph(app, api) {
  const workflows = app.extensionManager.workflow;
  const executionStore = () => workflows?._p?._s?.get("execution");
  let owned = null, baseline = null, loadedId = null, sequence = -1, currentNode;
  let terminal = null;
  let loading = false, reason = null, dispatching = false, explicitlyResumed = false;
  const fingerprint = () => {
    const graph = app.graph.serialize();
    return JSON.stringify({ nodes: graph.nodes, links: graph.links, groups: graph.groups });
  };
  const dispatch = (type, data) => {
    dispatching = true;
    try { api.dispatchEvent(new CustomEvent(type, { detail: data })); }
    finally { dispatching = false; }
  };
  const clear = () => {
    const execution = executionStore();
    if (owned) execution?.clearWorkflowStatus?.(owned);
    if (loadedId && execution?.activeJobId === loadedId) {
      execution.clearActiveJobIfStale?.(new Set());
      dispatch("executing", null);
      // executing(null) cancels the frontend's pending progress RAF. Send the
      // empty state afterwards so highlights really disappear when following stops.
      dispatch("progress_state", { prompt_id: loadedId, nodes: {} });
    }
    sequence = -1;
  };
  const pause = (why) => { reason = why; clear(); };
  const register = (record) => {
    const output = structuredClone(record.graph);
    for (const node of Object.values(output)) node._meta = { ...node._meta, title: node._meta?.title || node.class_type };
    executionStore().storeJob({ id: record.id, nodes: Object.keys(output), promptOutput: output, workflow: owned });
    dispatch("execution_start", { prompt_id: record.id });
  };
  const check = () => {
    if (!workflows || !executionStore()?.storeJob) return "unsupported";
    if (loading) return "loading";
    if (reason) return reason;
    const active = workflows.activeWorkflow;
    if (!active || !app.graph) return "initializing";
    if (owned && active !== owned) pause("tab");
    else if (owned && baseline !== fingerprint()) pause("editing");
    else if (!owned && active.isModified && !explicitlyResumed) pause("editing");
    return reason;
  };
  return {
    check,
    pause,
    watch(changed) {
      // Catch even a quick manual tab switch and switch back between polls.
      return workflows?.$subscribe?.(() => {
        if (loading) return;
        const previous = reason;
        check();
        if (reason !== previous) changed();
      }, { flush: "sync", detached: true }) || (() => {});
    },
    get loading() { return loading; },
    externalStart(id) { if (!dispatching && id !== loadedId) pause("manual"); },
    resume() {
      // Preserve an edited Ambient tab too. Resuming creates a separate view.
      if (owned && (workflows.activeWorkflow !== owned || baseline !== fingerprint())) owned = null;
      reason = null; loadedId = null; sequence = -1; explicitlyResumed = true;
    },
    async load(record) {
      if (check()) return false;
      if (loadedId === record.id) return true;
      const previous = owned;
      loading = true;
      clear();
      try {
        // loadApiJson reuses an active same-name workflow. Always choose a free
        // name, including when resuming from an edited Ambient view.
        const occupied = new Set((workflows.openWorkflows || []).map(w => w.path.split("/").pop()));
        let name = "Ambient Live", suffix = 2;
        while (occupied.has(`${name}.json`)) name = `Ambient Live (${suffix++})`;
        await app.loadApiJson(structuredClone(record.graph), name);
        owned = workflows.activeWorkflow;
        for (const saved of record.workflow?.nodes || []) {
          const node = app.graph.getNodeById(saved.id);
          if (!node) continue;
          if (saved.pos) node.pos = saved.pos;
          if (saved.size) node.size = saved.size;
          if (saved.title) node.title = saved.title;
        }
        baseline = fingerprint();
        loadedId = record.id; sequence = -1; currentNode = undefined; terminal = null;
        explicitlyResumed = false;
        // Only retire the untouched temporary tab that this adapter created.
        if (previous && previous !== owned && previous.isTemporary) await workflows.closeWorkflow(previous);
        register(record);
        return true;
      } finally { loading = false; }
    },
    show(record) {
      if (check() || loadedId !== record.id || !record.snapshot) return;
      const state = record.snapshot;
      app.nodeOutputs = record.outputs || {};
      const ended = ["completed", "failed", "cancelled"].includes(state.status);
      if (ended && terminal === state.status) return;
      // Native reconnect reconciliation can clear the store independently of
      // Ambient. Rehydrate even when the server sequence has not changed.
      if (!ended && executionStore().activeJobId !== record.id) {
        register(record); sequence = -1; currentNode = undefined;
      }
      const token = `${state.streamId}:${state.sequence}:${state.status}`;
      if (sequence === token) return;
      sequence = token;
      const nodes = state.nodes;
      const completed = Object.keys(nodes).filter(id => nodes[id].state === "finished");
      if (completed.length) dispatch("execution_cached", { prompt_id: record.id, nodes: completed });
      const node = nodes[state.currentNode];
      const display = node?.display_node_id ?? state.currentNode;
      if (display !== currentNode) {
        currentNode = display;
        dispatch("executing", display);
      }
      dispatch("progress_state", { prompt_id: record.id, nodes });
      if (state.step) dispatch("progress", { prompt_id: record.id, ...state.step, node: display ?? state.step.node });
      if (ended) {
        terminal = state.status;
        const type = { completed: "execution_success", failed: "execution_error", cancelled: "execution_interrupted" }[state.status];
        const detail = record.event?.type === type ? record.event.data : {
          prompt_id: record.id, node_id: null, node_type: "", executed: completed,
          exception_message: state.status === "failed" ? "Ambient execution failed. See ComfyUI history." : "",
          exception_type: "", traceback: [], current_inputs: {}, current_outputs: [],
        };
        dispatch(type, detail);
        dispatch("executing", null);
      }
    },
  };
}
