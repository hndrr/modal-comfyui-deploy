import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { executionGraph } from "./execution-graph.js";
import { executionSync } from "./execution-sync.js";

const request = async (path, body) => {
  const response = await api.fetchApi(`/ambient/${path}`, body ? {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
  } : {});
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || `HTTP ${response.status}`);
  return result;
};

app.registerExtension({
  name: "ambient.studio.workflows",
  async setup() {
    let root, records = [], catalog = { revision: 0, stages: {}, history: [] }, selected, draft, revision;
    let live = null;
    const graph = executionGraph(app, api);
    const session = document.createElement("select");
    const stage = document.createElement("select");
    const history = document.createElement("select");
    const status = document.createElement("p");
    const connection = document.createElement("p");
    connection.setAttribute("aria-label", "Ambient synchronization");
    status.setAttribute("aria-label", "Ambient execution progress");
    const progress = document.createElement("progress");
    progress.hidden = true;
    progress.setAttribute("aria-label", "Ambient node progress");
    const inputs = document.createElement("div");
    const results = document.createElement("pre");
    const ports = document.createElement("textarea");
    ports.rows = 7;
    ports.setAttribute("aria-label", "Ambient input and output bindings");
    const report = (error) => { status.textContent = String(error.message || error); };
    const button = (label, action) => {
      const item = document.createElement("button");
      item.textContent = label;
      item.onclick = () => void Promise.resolve().then(action).catch(report);
      return item;
    };
    const choose = () => records.find((record) =>
      record.meta.sessionId === session.value && record.meta.stage === stage.value);
    const fill = (select, values, preferred = select.value) => {
      select.replaceChildren(...values.map(([value, label]) => new Option(label, value)));
      if (values.some(([value]) => value === preferred)) select.value = preferred;
    };
    const draw = (state) => {
      live = state;
      records = [...state.records, ...Object.entries(catalog.stages).map(([stage, template]) => ({
        id: `template-${stage}-${catalog.revision}`, status: "template", graph: template.graph,
        workflow: template.workflow, outputs: {}, meta: { sessionId: "templates", stage,
          revision: catalog.revision, bindings: template.bindings, outputs: template.outputs },
      }))];
      const record = state.record;
      if (!draft) {
        fill(session, [...new Set(records.map(r => r.meta.sessionId))].map(id => [id,
          id === "templates" ? "ワークフローテンプレート" : `Session ${id.slice(0, 8)}`]), record?.meta.sessionId);
        fill(stage, [...new Set(records.filter(r => r.meta.sessionId === session.value).map(r => r.meta.stage))].map(id => [id, id]), record?.meta.stage);
      }
      fill(history, [...catalog.history].reverse().map(id => [String(id), `保存版 ${id}`]));
      const reasons = { editing: "編集中でグラフ追従停止", draft: "編集中でグラフ追従停止",
        tab: "タブ切替でグラフ追従停止", manual: "手動実行中でグラフ追従停止",
        selection: "選択中でグラフ追従停止", unsupported: "標準UI同期に対応していないComfyUIです",
        initializing: "ComfyUIの起動待ち", loading: "実行グラフを読み込み中" };
      connection.textContent = state.reconnecting ? "再接続中" : reasons[state.graphReason] || "自動追従中";
      if (state.error) connection.textContent += ` · ${state.error}`;
      const snapshot = record?.snapshot;
      const step = snapshot?.status === "running" ? snapshot.step : null;
      progress.hidden = !step;
      if (step) { progress.max = step.max; progress.value = step.value; }
      const label = { queued: "待機中", running: "実行中", finishing: "終了を確認中",
        completed: "完了", failed: "失敗", cancelled: "停止", unknown: "状態を確認中" };
      status.textContent = record ? `${record.meta.stage} · ${step
        ? `ステップ ${Math.round(step.value / step.max * 100)}% · ${step.value}/${step.max}`
        : label[snapshot?.status || record.status] || record.status}${snapshot?.currentNode != null
          ? ` · ノード ${snapshot.currentNode}` : ""} · 版 ${record.meta.revision}` : "Ambient生成を待っています";
      if (record && !snapshot) connection.textContent = "ComfyUI-Ambientの更新とComfyUIの再起動が必要です";
      results.textContent = JSON.stringify(record?.outputs || {}, null, 2);
    };
    const sync = executionSync({ api, graph, request, changed: draw });
    // Initial synchronization and recovery must work without ever opening this tab.
    sync.start();
    const catalogRefresh = async () => {
      try { catalog = await request("workflows"); if (live) draw(live); }
      catch (error) { report(error); }
    };
    api.addEventListener("ambient_workflows", () => { if (root?.isConnected) void catalogRefresh(); });
    const showInputs = () => {
      inputs.replaceChildren();
      for (const [name, binding] of Object.entries(draft.bindings)) {
        const label = document.createElement("label");
        label.textContent = `${name} `;
        const source = document.createElement("select");
        for (const [value, text] of [["ambient", "Ambientから入力"], ["workflow", "ワークフローの値"]]) {
          source.add(new Option(text, value));
        }
        source.value = binding.source || "ambient";
        source.onchange = () => { binding.source = source.value; ports.value = JSON.stringify({ bindings: draft.bindings, outputs: draft.outputs }, null, 2); };
        label.append(source);
        inputs.append(label, document.createElement("br"));
      }
      ports.value = JSON.stringify({ bindings: draft.bindings, outputs: draft.outputs }, null, 2);
    };
    const edit = async (template) => {
      selected = choose();
      if (!selected) throw new Error("Ambientでこの処理を一度実行してください。");
      sync.pause("draft");
      session.disabled = stage.disabled = true;
      draft = structuredClone(template || {
        graph: selected.graph, workflow: selected.workflow,
        bindings: selected.meta.bindings, outputs: selected.meta.outputs,
      });
      revision = catalog.revision;
      await app.loadApiJson(structuredClone(draft.graph), `Ambient Edit ${selected.meta.stage}`);
      for (const saved of draft.workflow?.nodes || []) {
        const node = app.graph.getNodeById(saved.id);
        if (!node) continue;
        if (saved.pos) node.pos = saved.pos;
        if (saved.size) node.size = saved.size;
        if (saved.title) node.title = saved.title;
      }
      showInputs();
      status.textContent = `編集中 · ${selected.meta.stage} · 基準版 ${revision}`;
    };
    app.extensionManager.registerSidebarTab({
      id: "ambient", icon: "pi pi-video", title: "Ambient", tooltip: "Ambientの実行内容とワークフロー", type: "custom",
      render(container) {
        root = container;
        const title = document.createElement("h3"); title.textContent = "Ambient";
        const details = document.createElement("details");
        const summary = document.createElement("summary"); summary.textContent = "入出力の接続先（ノードを置き換えた場合）";
        details.append(summary, ports);
        container.replaceChildren(title, connection, session, stage,
          button("自動追従を再開", () => {
            if (draft) throw new Error("編集を適用するか、破棄してから追従してください。");
            sync.resume();
          }),
          button("編集用に開く", () => edit()),
          button("編集を破棄", () => { draft = null; session.disabled = stage.disabled = false; inputs.replaceChildren(); sync.notify(); }),
          inputs, details,
          button("Ambientに適用", async () => {
            if (!draft) throw new Error("先に編集用に開いてください。");
            const exported = await app.graphToPrompt();
            const bindings = JSON.parse(ports.value);
            const template = { graph: exported.output, workflow: exported.workflow, ...bindings };
            await request("workflows/validate", { stage: selected.meta.stage, template });
            catalog = await request("workflows/apply", { stage: selected.meta.stage, template, expectedRevision: revision });
            draft = null; session.disabled = stage.disabled = false; inputs.replaceChildren();
            status.textContent = `版 ${catalog.revision} を保存しました。次の生成サイクルから使用します。`;
          }),
          history,
          button("保存版を編集用に復元", async () => {
            const old = await request(`workflows/${history.value}`);
            const template = old.stages[stage.value];
            if (!template) throw new Error("この版には編集済みワークフローがありません。");
            await edit(template);
          }), status, progress, results);
        container.style.cssText = "padding:12px;display:flex;flex-direction:column;gap:10px;overflow:auto";
        results.style.cssText = "white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px";
        session.setAttribute("aria-label", "Ambient session"); stage.setAttribute("aria-label", "Processing stage");
        session.onchange = () => {
          if (draft) return;
          fill(stage, [...new Set(records.filter(r => r.meta.sessionId === session.value).map(r => r.meta.stage))].map(id => [id, id]));
          sync.select(session.value, stage.value);
        };
        stage.onchange = () => { if (!draft) sync.select(session.value, stage.value); };
        sync.notify(); void catalogRefresh();
      },
    });
  },
});
