const VIDEO_STAGES = new Set(["h3", "h3-ref2v", "fasth3-8step-i2v-vsa", "fasth3-vsa-4step-i2v", "h3-turbo-4step", "h3-fused-4step", "fasth3", "fasth3-8step-t2v", "fasth3-8step-i2v"]);
const TERMINAL = new Set(["completed", "failed", "cancelled"]);

export function executionSync({ api, graph, request, changed }) {
  const records = new Map();
  const retiredStreams = new Set();
  let streamId;
  let target = null, busy = false, again = false, applying = false, timer;
  let reconnecting = false, error = null, disposed = false, pinned = null;
  const listeners = [];
  const notify = () => changed({ record: records.get(target) ?? null,
    records: [...records.values()].sort((a, b) => b.createdAt - a.createdAt),
    graphReason: graph.check(), reconnecting, error });
  const select = () => {
    const candidates = [...records.values()].filter(record => pinned
      ? record.meta.sessionId === pinned.sessionId && record.meta.stage === pinned.stage
      : VIDEO_STAGES.has(record.meta.stage));
    candidates.sort((a, b) => {
      const rank = (r) => ["running", "finishing"].includes(r.snapshot?.status || r.status) ? 0 : r.status === "queued" ? 1 : 2;
      return rank(a) - rank(b) || b.createdAt - a.createdAt;
    });
    target = candidates[0]?.id ?? null;
  };
  const merge = (record) => {
    const incomingStream = record.snapshot?.streamId;
    if (incomingStream && incomingStream !== streamId) {
      if (retiredStreams.has(incomingStream)) return;
      if (streamId) retiredStreams.add(streamId);
      streamId = incomingStream;
    }
    const prior = records.get(record.id);
    if (prior?.snapshot && record.snapshot?.streamId === prior.snapshot.streamId) {
      if (record.snapshot.sequence < prior.snapshot.sequence ||
          (record.snapshot.sequence === prior.snapshot.sequence && TERMINAL.has(prior.snapshot.status))) {
        record = { ...record, snapshot: prior.snapshot, status: prior.status, event: prior.event, outputs: prior.outputs };
      }
    }
    records.set(record.id, record);
    // Keep the same bound as the server. Retain the selected record if it is old.
    if (records.size > 100) for (const old of [...records.values()].sort((a, b) => a.createdAt - b.createdAt)) {
      if (old.id !== target) records.delete(old.id);
      if (records.size <= 100) break;
    }
  };
  const apply = async () => {
    notify();
    if (applying || disposed) return;
    applying = true;
    try {
      while (!disposed) {
        const record = records.get(target);
        if (!record?.snapshot || graph.check()) break;
        const id = record.id;
        if (!await graph.load(record)) break;
        if (target !== id) continue;
        graph.show(records.get(id));
        break;
      }
    } catch (cause) { error = String(cause.message || cause); }
    finally { applying = false; notify(); }
  };
  const refresh = async () => {
    if (disposed) return;
    if (busy) { again = true; return; }
    busy = true;
    try {
      const result = await request("executions");
      if (disposed) return;
      for (const record of result.executions) merge(record);
      reconnecting = false; error = null;
      select(); await apply();
    } catch (cause) { reconnecting = true; error = String(cause.message || cause); notify(); }
    finally {
      busy = false;
      if (again) { again = false; void refresh(); }
    }
  };
  const on = (type, listener) => { api.addEventListener(type, listener); listeners.push([type, listener]); };
  on("ambient_execution", ({ detail }) => {
    const state = detail.snapshot;
    if (!state || state.prompt_id !== detail.event?.data?.prompt_id) return;
    const record = records.get(state.prompt_id);
    if (!record) { void refresh(); return; }
    if (record.meta.sessionId !== detail.sessionId || record.meta.stage !== detail.stage) return;
    merge({ ...record, snapshot: state, status: state.status, event: detail.event });
    select(); void apply();
  });
  on("execution_start", ({ detail }) => { graph.externalStart(detail.prompt_id); notify(); });
  on("reconnecting", () => { reconnecting = true; notify(); });
  on("reconnected", () => { reconnecting = true; void refresh(); });
  const unwatch = graph.watch?.(notify);
  return {
    start() { timer = setInterval(() => void refresh(), 3000); void refresh(); },
    refresh,
    notify,
    pause(reason) { graph.pause(reason); notify(); },
    resume() { pinned = null; graph.resume(); select(); void apply(); void refresh(); },
    select(sessionId, stage) { pinned = { sessionId, stage }; graph.pause("selection"); select(); notify(); },
    dispose() {
      disposed = true; clearInterval(timer);
      unwatch?.();
      for (const [type, listener] of listeners) api.removeEventListener(type, listener);
    },
  };
}
