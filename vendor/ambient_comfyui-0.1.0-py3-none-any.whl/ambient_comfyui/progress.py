"""Recoverable execution state, independent of the last native notification."""
from copy import deepcopy
import math

TERMINAL = {"completed", "failed", "cancelled"}


def snapshot(prompt_id, stream_id, status="queued"):
    return {"prompt_id": prompt_id, "streamId": stream_id, "sequence": 0,
            "status": status, "currentNode": None, "nodes": {}, "step": None}


def valid_progress(data):
    value, maximum = data.get("value"), data.get("max")
    return (type(value) in (int, float) and type(maximum) in (int, float)
            and math.isfinite(value) and math.isfinite(maximum)
            and maximum > 0 and 0 <= value <= maximum)


def finish(state, status):
    state["status"], state["currentNode"], state["step"] = status, None, None
    for node in state["nodes"].values():
        if node["state"] == "running":
            node["state"] = "finished" if status == "completed" else "error"


def observe(state, kind, data, sequence):
    state["sequence"] = sequence
    # Native ComfyUI also sends executing(null) after a terminal event. Preserve
    # success/error/cancellation instead of replacing it with a generic end.
    if state["status"] in TERMINAL:
        return
    identity = state["prompt_id"]
    nodes = state["nodes"]

    def node_for(key, display=None):
        key = str(key)
        node = nodes.setdefault(key, {"node_id": key, "display_node_id": key,
                                     "prompt_id": identity, "state": "pending", "value": 0, "max": 1})
        if display is not None:
            node["display_node_id"] = str(display)
        return node

    if kind == "execution_start":
        state["status"] = "running"
    elif kind == "progress_state":
        for key, raw in data.get("nodes", {}).items():
            if not isinstance(raw, dict):
                continue
            node = node_for(key)
            previous = deepcopy(node)
            node.update(deepcopy(raw))
            if not valid_progress(node):
                node["value"], node["max"] = previous["value"], previous["max"]
            node["prompt_id"] = identity
            node["node_id"] = str(raw.get("node_id", key))
            node["display_node_id"] = str(raw.get("display_node_id", node["node_id"]))
            # A running-node notification with an indeterminate 0/1 counter must
            # not erase a real sampler counter received for that same node.
            if (previous["state"] == node["state"] == "running" and
                    previous["max"] > 1 and node.get("max", 1) <= 1):
                node["value"], node["max"] = previous["value"], previous["max"]
        running = [key for key, node in nodes.items() if node["state"] == "running"]
        if state["currentNode"] not in running:
            state["currentNode"] = running[0] if running else None
        state["status"] = "running"
    elif kind in {"executing", "progress"}:
        key = data.get("node")
        if key is None and kind == "progress":
            key = state["currentNode"]
        if key is not None:
            key = str(key)
            previous = state["currentNode"]
            if previous != key:
                state["step"] = None
                if previous in nodes and nodes[previous]["state"] == "running":
                    nodes[previous]["state"] = "finished"
            node = node_for(key, data.get("display_node"))
            if node["state"] != "running":
                node.update(value=0, max=1)
            node["state"] = "running"
            state["currentNode"], state["status"] = key, "running"
            if kind == "progress" and valid_progress(data):
                node.update(value=data["value"], max=data["max"])
                state["step"] = {"node": key, "value": data["value"], "max": data["max"]}
        elif kind == "executing":
            state["currentNode"], state["step"] = None, None
            state["status"] = "finishing"
    elif kind in {"execution_cached", "executed"}:
        keys = data.get("nodes", []) if kind == "execution_cached" else [data.get("node")]
        for key in keys:
            if key is not None:
                node_for(key)["state"] = "finished"
    elif kind in {"execution_success", "execution_error", "execution_interrupted"}:
        finish(state, {"execution_success": "completed", "execution_error": "failed",
                       "execution_interrupted": "cancelled"}[kind])
        return

    current = nodes.get(state["currentNode"])
    if not current or current["state"] != "running":
        state["step"] = None
    elif valid_progress(current) and current["max"] > 1:
        state["step"] = {"node": current["node_id"], "value": current["value"], "max": current["max"]}
