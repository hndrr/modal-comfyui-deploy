"""Model profiles for Local ComfyUI and the optional Modal adapter."""

from .contracts import FAST8_MODES

MODEL_FILES = {
    "unet": "minimax_h3_fl2va_pruned_int8_convrot.safetensors",
    "clip": "qwen3vl_32b_minimax_h3_int8_convrot.safetensors",
    "video_vae": "minimax_h3_video_vae_int8_convrot.safetensors",
    "audio_vae": "minimax_h3_audio_vae_fp32.safetensors",
    "lora": "Lora/h3/minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors",
}
FAST_MODEL_FILES = {
    **{key: value for key, value in MODEL_FILES.items() if key != "lora"},
    "unet": "minimax_h3_fastvideo_vsa_datafree_1300step_4step_int8_convrot.safetensors",
}
FAST8_MODEL_FILES = {
    **FAST_MODEL_FILES,
    "unet": "fastvideo_fasth3_8step_v2_pruned_int8_convrot.safetensors",
}
FUSED_MODEL_FILES = {
    **FAST_MODEL_FILES,
    "unet": "minimax_h3_fused_refdelta_r1024_turbo8_mystic07_int8_convrot.safetensors",
}
MODE_MODEL_FILES = {
    "h3-ref2v": {**FAST_MODEL_FILES, "unet": "minimax_h3_ref2va_pruned_int8_convrot.safetensors"},
    "h3": MODEL_FILES,
    "h3-turbo-4step": MODEL_FILES,
    "h3-fused-4step": FUSED_MODEL_FILES,
    "fasth3": FAST_MODEL_FILES,
    **{mode: FAST8_MODEL_FILES for mode in FAST8_MODES},
}

# Preserve each target's existing filenames; selecting a profile never downloads.
MODAL_MODE_MODEL_FILES = {
    mode: {**files, "clip": "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors",
           **({"lora": "minimax_h3_fl2v_turbo_8step_v1.0_comfyui_bf16.safetensors"} if "lora" in files else {})}
    for mode, files in MODE_MODEL_FILES.items()
}
PROFILES = {"local": MODE_MODEL_FILES, "modal": MODAL_MODE_MODEL_FILES}
REF_MODELS = ("minimax_h3_ref2va_pruned_int8_convrot.safetensors", "minimax_h3_ref2va_int8_convrot.safetensors")
