"""Optional adapter to split's public controller boundary; no Modal SDK import."""

import asyncio
from copy import deepcopy
from importlib.resources import files
import json
from uuid import uuid4

from aiohttp import web

from . import saved_library
from .contracts import DEFAULT_BACKENDS
from .events import EXECUTION_EVENTS
from .h3 import workflow
from .progress import snapshot, observe, finish, TERMINAL
from .tagging import recipe
from .workflows import WorkflowRegistry, h3_metadata, pin_references, validate_template


class SplitAmbient:
    def __init__(self, controller):
        self.controller = controller
        # Reuse the durable single-writer journal, including old saved revisions.
        self.registry = WorkflowRegistry(controller.journal.data, preserve_defaults=True)
        self.templates_loaded = False
        self.stream = str(uuid4())
        self.sequence = 0
        self.progress = {}

    async def start(self):
        pass

    async def close(self):
        self.progress.clear()

    def prepare(self, body):
        return self.registry.prepare(body)

    def event(self, event):
        if not isinstance(event, dict) or event.get("type") not in EXECUTION_EVENTS:
            return ()
        data = event.get("data", {})
        job = self.controller.journal.data["jobs"].get(data.get("prompt_id"))
        meta = job and job.get("body", {}).get("extra_data", {}).get("ambient")
        if not meta:
            return ()
        self.sequence += 1
        state = self.progress.setdefault(job["id"], snapshot(job["id"], self.stream))
        observe(state, event["type"], data, self.sequence)
        job["ambient_event"] = deepcopy(event)
        if event["type"] == "progress_state":
            job["ambient_progress_state"] = deepcopy(event)
        return ({"type": "ambient_execution", "data": {
            "sessionId": meta["sessionId"], "stage": meta["stage"],
            "event": deepcopy(event), "snapshot": deepcopy(state)}},)

    def executions(self, identity=None, session=None):
        records = []
        for job in self.controller.journal.data["jobs"].values():
            meta = job.get("body", {}).get("extra_data", {}).get("ambient")
            if not meta or (identity and job["id"] != identity) or (session and meta["sessionId"] != session):
                continue
            state = deepcopy(self.progress.get(job["id"])) or snapshot(job["id"], self.stream, job["status"])
            if job["status"] in TERMINAL:
                finish(state, job["status"])
            records.append({"id": job["id"], "status": job["status"], "createdAt": job["created_at"],
                "graph": job["body"]["prompt"], "meta": meta,
                "workflow": meta.get("layout") or job["body"].get("extra_data", {}).get("extra_pnginfo", {}).get("workflow"),
                "event": job.get("ambient_event"), "progressState": job.get("ambient_progress_state"),
                "outputs": (job.get("history") or {}).get("outputs", {}), "snapshot": state})
        records.sort(key=lambda record: record["createdAt"], reverse=True)
        return {"executions": records[:100]}

    async def templates(self):
        c = self.controller
        objects = json.loads((await c.objects("/object_info")).body)
        async with c.lock:
            if self.templates_loaded:
                return
            request = {"requestId": "00000000-0000-4000-8000-000000000000",
                "sessionId": "00000000-0000-4000-8000-000000000000", "workflowRevision": 0,
                "prompt": "A quiet natural scene", "sound": "Soft ambient sounds", "seed": 42,
                "resolution": "preview"}
            for mode in DEFAULT_BACKENDS:
                try:
                    req = {**request, "mode": mode}
                    graph = workflow(req, object_info=objects, profile="modal")
                    metadata = h3_metadata(req, graph)
                    self.registry.state["defaults"][mode] = {"graph": graph,
                        "bindings": metadata["bindings"], "outputs": metadata["outputs"], "workflow": None}
                except ValueError:
                    continue  # Readiness reports missing models or node definitions.
            if "JevInterpret" in objects:
                self.registry.prepare(recipe({}, request["sessionId"], 0))
            templates = json.loads(files(__package__).joinpath("bridge_templates.json").read_text())
            for stage, template in templates.items():
                if all(node["class_type"] in objects for node in template["graph"].values()):
                    self.registry.state["defaults"][stage] = template
            self.registry.upgrade_lengths()
            await c.persist()
            self.templates_loaded = True

    async def handle(self, request, path):
        if not path.startswith("/ambient/"):
            return None
        c = self.controller
        library_response = await saved_library.handle(request, path, c.volumes["output"])
        if library_response is not None:
            return library_response
        if path == "/ambient/v1/capabilities" and request.method == "GET":
            return web.json_response({"api_version": 1, "kind": "modal-split", "scopedCancel": True,
                "executionSyncVersion": 2, "dependencies": getattr(c.cpu, "dependencies", {})})
        if path == "/ambient/workflows" and request.method == "GET":
            if not self.templates_loaded:
                await self.templates()
            return web.json_response(self.registry.describe())
        if path.startswith("/ambient/workflows/") and request.method == "GET":
            return web.json_response(self.registry.describe(int(path.rsplit("/", 1)[-1])))
        if path in {"/ambient/workflows/apply", "/ambient/workflows/validate"} and request.method == "POST":
            payload = await request.json()
            objects = json.loads((await c.objects("/object_info")).body)
            async with c.lock:
                baseline = self.registry.state["defaults"][payload["stage"]]
                validate_template(payload["template"], baseline, objects)
                if path.endswith("/validate"):
                    return web.json_response({"valid": True})
                if payload["expectedRevision"] != self.registry.state["revision"]:
                    raise ValueError("Workflow changed on another device. Reload before applying.")
                template = await asyncio.to_thread(pin_references, payload["template"], c.volumes["input"])
                result = self.registry.apply(payload["stage"], template, payload["expectedRevision"], objects)
                await c.persist()
            await c.broadcast({"type": "ambient_workflows", "data": {"revision": result["revision"]}})
            return web.json_response(result)
        if (path == "/ambient/executions" or path.startswith("/ambient/executions/")) and request.method == "GET":
            identity = None if path == "/ambient/executions" else path.rsplit("/", 1)[-1]
            return web.json_response(self.executions(identity, request.query.get("sessionId")))
        return web.json_response({"error": "Unknown Ambient route"}, status=404)
