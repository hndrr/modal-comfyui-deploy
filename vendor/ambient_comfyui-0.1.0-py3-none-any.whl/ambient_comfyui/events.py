"""Mirror Ambient execution events without changing native socket routing."""
from functools import wraps
import logging

EXECUTION_EVENTS = {
    "execution_start", "execution_cached", "executing", "progress", "progress_state",
    "executed", "execution_success", "execution_error", "execution_interrupted",
}


def mirror_events(server, observe):
    # send_json runs on ComfyUI's event loop, after the worker's thread-safe
    # send_sync queue. Keep the original delivery (including its client ID).
    original = server.send_json

    @wraps(original)
    async def send_json(event, data, sid=None):
        result = await original(event, data, sid)
        if event in EXECUTION_EVENTS and isinstance(data, dict):
            try:
                mirrored = observe(event, data)
                if mirrored:
                    await original("ambient_execution", mirrored)
            except Exception:
                # A sidebar failure must never interrupt the native publisher.
                logging.exception("Could not mirror Ambient execution progress")
        return result

    server.send_json = send_json
