"""Read existing Modal library data without the retired Ambient application.

No creation, migration, deletion, tagging or generation is performed here.
"""
from copy import deepcopy
from uuid import UUID

from aiohttp import web

LIBRARY = "comfyui-ambient-library"


def identifier(value):
    try:
        if str(UUID(value)) != value:
            raise ValueError()
    except (ValueError, TypeError, AttributeError):
        raise web.HTTPNotFound()
    return value


def catalog(records):
    clips = []
    for key, record in records.items():
        if not key.startswith("clip:") or not isinstance(record, dict):
            continue
        identity = key.removeprefix("clip:")
        identifier(identity)
        if record.get("id") != identity or records.get("deleted:" + identity):
            continue
        clips.append({**deepcopy(record), "tagging": deepcopy(records.get("tags:" + identity, {"status": "untagged"}))})
    clips.sort(key=lambda clip: (clip["createdAt"], clip["id"]), reverse=True)
    return {"clips": clips, "count": len(clips), "bytes": sum(clip.get("bytes", 0) for clip in clips)}


async def read_records():
    # Native installations and split deployments that never browse the saved
    # library do not import the SDK or look up the old Dict.
    import modal
    try:
        records = modal.Dict.from_name(LIBRARY, create_if_missing=False)
        return {key: value async for key, value in records.items.aio()}
    except modal.exception.NotFoundError:
        return {}


async def handle(request, path, output_volume):
    if not path.startswith("/ambient/library"):
        return None
    if request.method != "GET":
        raise web.HTTPMethodNotAllowed(request.method, ["GET"])
    if path == "/ambient/library":
        return web.json_response(catalog(await read_records()))
    parts = path.split("/")
    if len(parts) != 5 or parts[-1] != "video":
        raise web.HTTPNotFound()
    identity = identifier(parts[3])
    records = await read_records()
    record = records.get("clip:" + identity)
    if not record or record.get("id") != identity or records.get("deleted:" + identity):
        raise web.HTTPNotFound()
    chunks = output_volume.read_file.aio(f"ambient/library/{identity}.mp4")
    try:
        first = await anext(chunks)
    except (FileNotFoundError, StopAsyncIteration):
        raise web.HTTPNotFound()

    async def media():
        try:
            yield first
            async for chunk in chunks:
                yield chunk
        finally:
            await chunks.aclose()
    return web.Response(body=media(), content_type="video/mp4", headers={"Cache-Control": "private, no-store"})
