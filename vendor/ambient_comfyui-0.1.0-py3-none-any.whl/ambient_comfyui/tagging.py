"""Jev tagging is a separate ComfyUI job, never a prerequisite for playback."""
import json
from uuid import uuid4


SCHEMA = {
    "scene": {"type": "multi_choice", "instructions": "Select visual scene tags supported by the generation instructions.",
              "criteria": {k: k for k in ("forest", "water", "ocean", "mountain", "city", "interior", "abstract", "night", "day", "rain", "snow", "fog", "space", "waveform", "lissajous", "glitch", "electronic", "neon", "feedback")}},
    "sound": {"type": "multi_choice", "instructions": "Select audible elements requested in the sound instructions.",
              "criteria": {k: k for k in ("rain", "wind", "water", "birds", "insects", "urban", "mechanical", "music", "voices", "quiet", "guitar", "percussion", "drums", "bass", "electronic", "sine", "shoegaze", "uk_garage", "glitch")}},
    "motion": {"type": "score", "instructions": "How much visual movement is requested?", "criteria": ["Still", "Gentle", "Energetic"]},
    "warmth": {"type": "score", "instructions": "How warm is the visual atmosphere?", "criteria": ["Cold", "Neutral", "Warm"]},
    "dream": {"type": "score", "instructions": "How dreamlike is the scene?", "criteria": ["Literal realistic", "Atmospheric", "Surreal dream"]},
}


def recipe(state, session_id, revision):
    # Current Jev exposes one judgment per Interpret node and returns its resolved
    # value directly. One shared state input keeps every judgment in sync when a
    # saved workflow receives the next generation's effective settings.
    graph = {"1": {"class_type": "PrimitiveStringMultiline", "inputs": {
        "value": json.dumps(state, ensure_ascii=False)}}}
    outputs = {}
    for index, (name, field) in enumerate(SCHEMA.items()):
        node, preview = str(2 + index * 2), str(3 + index * 2)
        candidates = str(100 + index)
        graph[candidates] = {"class_type": "PrimitiveStringMultiline", "inputs": {
            "value": json.dumps(list(field["criteria"]))}}
        graph[node] = {"class_type": "JevInterpret", "inputs": {
            "state": ["1", 0], "instructions": field["instructions"], "task": field["type"],
            "candidates_json": [candidates, 0],
            "model": "jev-latest", "refresh": 0, "provider": "typesafe", "api_key": ""}}
        graph[preview] = {"class_type": "PreviewAny", "inputs": {"source": [node, 0]}}
        outputs[name] = preview
    return {"prompt": graph, "client_id": str(uuid4()), "extra_data": {"ambient": {
        "sessionId": session_id, "stage": "jev", "revision": revision,
        "bindings": {"state": {"node": "1", "input": "value", "source": "ambient"}}, "outputs": outputs}}}

