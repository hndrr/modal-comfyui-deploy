RESOLUTIONS = {"preview": (832, 480), "quality": (1344, 768)}
# Exact ratios on H3's 32-pixel grid.
ASPECT_RATIOS = {
    "16:9": {"preview": (1024, 576), "quality": (1536, 864)},
    "9:16": {"preview": (576, 1024), "quality": (864, 1536)},
    "1:1": {"preview": (640, 640), "quality": (1024, 1024)},
    "4:3": {"preview": (768, 576), "quality": (1152, 864)},
    "3:4": {"preview": (576, 768), "quality": (864, 1152)},
}
FRAMES = 124
FPS = 24
FAST8_MODES = {"fasth3-8step-t2v", "fasth3-8step-i2v"}
FAST8_MODES |= {"fasth3-8step-i2v-vsa", "fasth3-vsa-4step-i2v"}
I2V_MODES = {"fasth3-8step-i2v", "fasth3-8step-i2v-vsa", "fasth3-vsa-4step-i2v"}
H3_FOUR_STEP_MODES = {"h3-turbo-4step", "h3-fused-4step"}
IMAGE_MODES = {"h3", *H3_FOUR_STEP_MODES, *I2V_MODES}
DEFAULT_BACKENDS = {mode: "comfyui" for mode in (
    "h3", "h3-turbo-4step", "h3-fused-4step", "fasth3", "fasth3-8step-t2v", "fasth3-8step-i2v",
    "h3-ref2v", "fasth3-8step-i2v-vsa", "fasth3-vsa-4step-i2v",
)}


def generation_size(request: dict) -> tuple[int, int]:
    # Requests accepted before aspect-ratio support keep their original dimensions.
    sizes = ASPECT_RATIOS[request["aspectRatio"]] if "aspectRatio" in request else RESOLUTIONS
    return sizes[request["resolution"]]


MUSIC_DIRECTION = "Follow overall_soundscape for music, rhythm, percussion and silence."

def prompt_text(request: dict) -> str:
    return (f"integrated_multimodal_description: [Shot 1] {request['prompt']}\n\n"
            f"overall_soundscape: {request['sound']}\n\nnon_diegetic_music: {MUSIC_DIRECTION}")
