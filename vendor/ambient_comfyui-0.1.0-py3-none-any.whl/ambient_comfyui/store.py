"""Durable local adapters for the Ambient store and media interfaces."""
from contextlib import contextmanager
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sqlite3
import threading
from uuid import uuid4


class SQLiteStore:
    def __init__(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(path, check_same_thread=False, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS records (key TEXT PRIMARY KEY, value TEXT NOT NULL)")

    @contextmanager
    def transaction(self):
        with self.lock:
            self.db.execute("BEGIN IMMEDIATE")
            try:
                yield self
                self.db.execute("COMMIT")
            except BaseException:
                self.db.execute("ROLLBACK")
                raise

    def get(self, key, default=None):
        with self.lock:
            row = self.db.execute("SELECT value FROM records WHERE key=?", (key,)).fetchone()
        return json.loads(row[0]) if row else default

    def __getitem__(self, key):
        value = self.get(key)
        if value is None:
            raise KeyError(key)
        return value

    def put(self, key, value, skip_if_exists=False):
        with self.lock:
            cursor = self.db.execute(
                "INSERT OR IGNORE INTO records VALUES (?, ?)" if skip_if_exists else
                "INSERT INTO records VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (key, json.dumps(value, allow_nan=False)),
            )
            return cursor.rowcount == 1

    def items(self):
        with self.lock:
            return [(key, json.loads(value)) for key, value in self.db.execute("SELECT key,value FROM records")]

    def pop(self, key, default=None):
        with self.lock:
            value = self.get(key, default)
            self.db.execute("DELETE FROM records WHERE key=?", (key,))
            return value

    def close(self):
        with self.lock:
            self.db.close()


class FileVolume:
    """Only the small file interface used by Ambient; no Modal SDK dependency."""
    def __init__(self, root):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def path(self, name):
        path = PurePosixPath(name)
        if path.is_absolute() or ".." in path.parts or "\\" in str(name):
            raise ValueError("Expected a relative asset path")
        result = (self.root / path).resolve()
        if not result.is_relative_to(self.root):
            raise ValueError("Asset path leaves its storage directory")
        return result

    @contextmanager
    def batch_upload(self, **_kwargs):
        yield self

    def put_file(self, source, name):
        destination = self.path(name)
        destination.parent.mkdir(parents=True, exist_ok=True)
        temporary = destination.with_name(destination.name + "." + uuid4().hex + ".part")
        try:
            with temporary.open("xb") as handle:
                if hasattr(source, "read"):
                    shutil.copyfileobj(source, handle)
                else:
                    with Path(source).open("rb") as incoming:
                        shutil.copyfileobj(incoming, handle)
                handle.flush()
                os.fsync(handle.fileno())
            temporary.replace(destination)
            if os.name != "nt":  # Windows does not support opening directories this way.
                descriptor = os.open(destination.parent, os.O_RDONLY)
                try:
                    os.fsync(descriptor)
                finally:
                    os.close(descriptor)
        finally:
            temporary.unlink(missing_ok=True)

    def read_file_into_fileobj(self, name, handle):
        with self.path(name).open("rb") as source:
            shutil.copyfileobj(source, handle)

    def remove_file(self, name):
        self.path(name).unlink(missing_ok=True)

    def reload(self):
        pass

    def commit(self):
        pass  # put_file publishes durably.

