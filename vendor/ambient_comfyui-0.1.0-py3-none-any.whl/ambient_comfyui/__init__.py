"""Shared Ambient contracts. Importing never registers ComfyUI routes."""

__version__ = "0.1.0"
